 <!--Footer-->
 <footer class="main-footer">
    <div class="text-center">
    Copyright © 2023 RRD 369 Marketing
    </div>
 </footer>
 <!--/Footer-->

 <!--app closed-->
