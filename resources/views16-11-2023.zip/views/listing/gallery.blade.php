@extends('layouts.app')

@section('content')

<main class="main__content_wrapper">
        
<h1 class="text-center"><br/>Video Gallery</h1>


  <!-- Start portfolio section -->
        <section class="portfolio__section section--padding">
            <div class="container">
                <div class="section__heading text-center mb-40">
                    <h2 class="section__heading--maintitle">Watch Our Portfolio</h2>
                </div>
                
            </div>
        </section>
        <!-- End portfolio section -->
     @endsection